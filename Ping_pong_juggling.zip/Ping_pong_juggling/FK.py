import sympy as sp

def symbolic_fk_5dof():
    # Define symbolic joint variables
    q = sp.symbols('q0:5')  # q0, q1, q2, q3, q4

    # Example DH parameters: [theta, d, a, alpha]
    dh_params = [
        [q[0], 0.1, 0.0, -sp.pi/2],
        [q[1], 0.0, 0.3,  0.0     ],
        [q[2], 0.0, 0.3,  0.0     ],
        [q[3], 0.0, 0.1,  sp.pi/2 ],
        [q[4], 0.0, 0.1,  0.0     ]
    ]

    def dh_transform(theta, d, a, alpha):
        return sp.Matrix([
            [sp.cos(theta), -sp.sin(theta)*sp.cos(alpha),  sp.sin(theta)*sp.sin(alpha), a*sp.cos(theta)],
            [sp.sin(theta),  sp.cos(theta)*sp.cos(alpha), -sp.cos(theta)*sp.sin(alpha), a*sp.sin(theta)],
            [0,              sp.sin(alpha),                sp.cos(alpha),               d],
            [0,              0,                            0,                           1]
        ])

    # Compose transformation matrices
    T = sp.eye(4)
    for theta, d, a, alpha in dh_params:
        T = T @ dh_transform(theta, d, a, alpha)

    # Extract end-effector position
    pos = T[:3, 3]

    # Convert symbolic expression to a numerical function
    fk_func = sp.lambdify(q, pos, modules='numpy')

    return fk_func
