import numpy as np
import pybullet as p

def compute_torque_control(robot_id, joint_indices, q, dq, q_d, dq_d, ddq_d,
                           Kp=None, Kd=None):
    """
    Computes joint torques using inverse dynamics and PD feedback.

    Args:
        q, dq: current joint pos/vel (from PyBullet)
        q_d, dq_d, ddq_d: desired pos/vel/acc (from MPC)
    """

    dof = len(joint_indices)
    if Kp is None:
        Kp = np.eye(dof) * 150.0
    if Kd is None:
        Kd = np.eye(dof) * 20.0

    # PD tracking error
    pos_error = np.array(q_d) - np.array(q)
    vel_error = np.array(dq_d) - np.array(dq)

    # Desired acceleration with PD
    ddq_cmd = np.array(ddq_d) + Kd @ vel_error + Kp @ pos_error

    # Inverse dynamics: M*ddq + C*dq + G
    tau = p.calculateInverseDynamics(
        bodyUniqueId=robot_id,
        objPositions=q,
        objVelocities=dq,
        objAccelerations=ddq_cmd
    )

    return tau
