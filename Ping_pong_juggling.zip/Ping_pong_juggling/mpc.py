import casadi as ca
import numpy as np
from FK import symbolic_fk_5dof

def casadi_dh_transform(theta, d, a, alpha):
    ct = ca.cos(theta)
    st = ca.sin(theta)
    ca_ = ca.cos(alpha)
    sa = ca.sin(alpha)

    return ca.vertcat(
        ca.horzcat(ct, -st * ca_, st * sa, a * ct),
        ca.horzcat(st, ct * ca_, -ct * sa, a * st),
        ca.horzcat(0, sa, ca_, d),
        ca.horzcat(0, 0, 0, 1)
    )

def casadi_fk():
    q = ca.MX.sym('q', 5)

    dh_params = [
        (q[0], 0.1, 0.0, -ca.pi/2),
        (q[1], 0.0, 0.3, 0.0),
        (q[2], 0.0, 0.3, 0.0),
        (q[3], 0.0, 0.1, ca.pi/2),
        (q[4], 0.0, 0.1, 0.0),
    ]

    T = ca.MX.eye(4)
    for theta, d, a, alpha in dh_params:
        T = ca.mtimes(T, casadi_dh_transform(theta, d, a, alpha))

    position = T[:3, 3]
    fk_func = ca.Function("fk", [q], [position])
    return fk_func


def solve_mpc(
    q0, dq0,
    target_paddle_pos,
    target_paddle_vel,
    forward_kinematics_func,
    horizon=20, dt=0.05,
    dof=5
):
    # Variables
    q = ca.MX.sym('q', dof, horizon)
    dq = ca.MX.sym('dq', dof, horizon)
    ddq = ca.MX.sym('ddq', dof, horizon)

    # Objective
    cost = 0
    for n in range(horizon):
        cost += ca.dot(dq[:,n], dq[:,n]) + 100 * ca.dot(ddq[:,n], ddq[:,n])

    # Constraints list
    g = []

    # Initial state constraint
    g.append(q[:, 0] - ca.DM(q0))
    g.append(dq[:, 0] - ca.DM(dq0))

    # Dynamics (Euler integration)
    for n in range(horizon - 1):
        g.append(q[:, n+1] - (q[:, n] + dq[:, n]*dt))
        g.append(dq[:, n+1] - (dq[:, n] + ddq[:, n]*dt))

    # Final paddle pose constraint
    fk = casadi_fk()
    paddle_pos = fk(q[:, -1])
    g.append(paddle_pos - ca.DM(target_paddle_pos))

    # Flatten constraints
    g = ca.vertcat(*g)

    # Decision variables
    X = ca.vertcat(q.reshape((-1, 1)), dq.reshape((-1, 1)), ddq.reshape((-1, 1)))

    # NLP
    nlp = {'x': X, 'f': cost, 'g': g}
    solver = ca.nlpsol('solver', 'ipopt', nlp)

    # Initial guess
    x0 = np.zeros(X.shape)

    # Solve
    sol = solver(x0=x0, lbg=0, ubg=0)

    # Extract solution
    x_opt = sol['x'].full().flatten()

    # Parse back into q, dq, ddq
    q_opt = x_opt[0 : dof*horizon].reshape((dof, horizon))
    dq_opt = x_opt[dof*horizon : 2*dof*horizon].reshape((dof, horizon))
    ddq_opt = x_opt[2*dof*horizon : ].reshape((dof, horizon))

    return q_opt, dq_opt, ddq_opt

