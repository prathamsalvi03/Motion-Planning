import numpy as np

GRAVITY = 9.81
RESTITUTION_COEFF = 0.9  # Assumed energy loss on contact
TARGET_BOUNCE_HEIGHT = 0.6  # meters

def predict_contact_time(ball_z, ball_vz, target_height=0.0):
    """
    Predict time when ball reaches target height.
    """
    a = -0.5 * GRAVITY
    b = ball_vz
    c = ball_z - target_height

    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return None

    t1 = (-b + np.sqrt(discriminant)) / (2 * a)
    t2 = (-b - np.sqrt(discriminant)) / (2 * a)

    # Return the smallest positive time
    t_contact = min([t for t in [t1, t2] if t > 0], default=None)
    return t_contact

def compute_required_paddle_state(ball_pos, ball_vel, t_contact, h_bounce=0.6, restitution=0.9):
    """
    Compute desired paddle contact state.
    """
    ball_pos = np.array(ball_pos)
    ball_vel = np.array(ball_vel)

    if t_contact is None:
        return None

    # Predict contact point
    contact_pos_xy = ball_pos[:2] + ball_vel[:2] * t_contact
    contact_z = ball_pos[2] + ball_vel[2] * t_contact - 0.5 * 9.81 * t_contact**2
    contact_point = np.array([contact_pos_xy[0], contact_pos_xy[1], contact_z])

    # Desired vertical speed for bounce
    v_out_z = np.sqrt(2 * 9.81 * h_bounce)

    v_out = np.array([
        (contact_point[0] - ball_pos[0]) / t_contact,
        (contact_point[1] - ball_pos[1]) / t_contact,
        v_out_z
    ])

    v_paddle = (v_out / restitution) - ball_vel
    paddle_normal = np.array([0, 0, 1])

    return {
        'contact_time': t_contact,
        'contact_point': contact_point,
        'paddle_velocity': v_paddle,
        'paddle_normal': paddle_normal
    }