import pybullet as p
import pybullet_data
import time
import os
import numpy as np

class PingPongEnv:
    def __init__(self, urdf_root="urdf", gui=True):
        self.urdf_root = urdf_root
        self.gui = gui

        # Connect to PyBullet
        if gui:
            p.connect(p.GUI)
        else:
            p.connect(p.DIRECT)

        # Basic setup
        p.setGravity(0, 0, -9.81)
        p.setTimeStep(1.0 / 240.0)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())

        # Load world
        self._load_world()

    def _load_world(self):
        # Load ground plane
        p.loadURDF("plane.urdf")

        # Load 5-DOF arm
        arm_path = "universalUR5.urdf"
        self.robot_id = p.loadURDF(arm_path, basePosition=[0, 0, 0], useFixedBase=True)
        start_pos = [0, 0, 0.88]  # Example position
        start_orientation = [np.pi/2, 0, np.pi / 2, 1]  # Example orientation (quaternion)
        p.resetBasePositionAndOrientation(self.robot_id, start_pos, start_orientation)

        # Load ping pong ball
        ball_radius = 0.02
        self.ball_id = p.createMultiBody(
            baseMass=0.0027,
            baseCollisionShapeIndex=p.createCollisionShape(p.GEOM_SPHERE, radius=ball_radius),
            baseVisualShapeIndex=p.createVisualShape(p.GEOM_SPHERE, radius=ball_radius, rgbaColor=[1, 0.5, 0, 1]),
            basePosition=[0.0, 0.0, 1.0]
        )

        # Disable default motors
        self.num_joints = p.getNumJoints(self.robot_id)
        for i in range(self.num_joints):
            p.setJointMotorControl2(self.robot_id, i, controlMode=p.VELOCITY_CONTROL, force=0)

    def get_ball_state(self):
        pos, _ = p.getBasePositionAndOrientation(self.ball_id)
        vel, _ = p.getBaseVelocity(self.ball_id)
        return pos, vel

    def get_joint_states(self):
        joint_states = p.getJointStates(self.robot_id, list(range(self.num_joints)))
        q = [s[0] for s in joint_states]
        dq = [s[1] for s in joint_states]
        return q, dq

    def apply_joint_torques(self, torques):
        p.setJointMotorControlArray(
            bodyUniqueId=self.robot_id,
            jointIndices=list(range(self.num_joints)),
            controlMode=p.TORQUE_CONTROL,
            forces=torques
        )

    def step(self):
        p.stepSimulation()

    def reset_ball(self, pos=[0, 0, 1.0], vel=[0, 0, 0]):
        p.resetBasePositionAndOrientation(self.ball_id, pos, [0, 0, 0, 1])
        p.resetBaseVelocity(self.ball_id, vel, [0, 0, 0])


# Example usage
if __name__ == "__main__":
    env = PingPongEnv(gui=True)
    for _ in range(10000):
        env.step()
        time.sleep(1/240)
