import numpy as np
from Sim import PingPongEnv
from HL_paddle import predict_contact_time, compute_required_paddle_state
from FK import symbolic_fk_5dof
from mpc import solve_mpc,casadi_fk
from Low_LQR import compute_torque_control


env = PingPongEnv(gui=True)
joint_indices = list(range(env.num_joints))
paddle_link_index = 6  # Adjust if needed
fk = casadi_fk()  # CasADi-based symbolic forward kinematics

# === CONTROL PARAMETERS ===
horizon = 20
dt = 0.05

# === SIM LOOP ===
print("[INFO] Starting simulation...")
mpc_active = False
mpc_step = 0
q_traj = dq_traj = ddq_traj = None

for step in range(10000):
    q, dq = env.get_joint_states()
    ball_pos, ball_vel = env.get_ball_state()

    if not mpc_active:
        # === HIGH-LEVEL CONTROLLER ===
        t_contact = predict_contact_time(ball_pos[2], ball_vel[2])
        if t_contact:
            paddle_target = compute_required_paddle_state(ball_pos, ball_vel, t_contact)
            if paddle_target:
                target_pos = paddle_target['contact_point']
                target_vel = paddle_target['paddle_velocity']

                print(f"[INFO] Predicting contact at {target_pos} in {t_contact:.2f}s")

                # === MPC PLANNER ===
                q_traj, dq_traj, ddq_traj = solve_mpc(
                    q0=q,
                    dq0=dq,
                    target_paddle_pos=target_pos,
                    target_paddle_vel=target_vel,  # Not yet enforced
                    forward_kinematics_func=lambda q, dq: (fk(q), np.zeros(3)),
                    horizon=horizon,
                    dt=dt,
                    dof=5
                )

                mpc_active = True
                mpc_step = 0

    # === LOW-LEVEL CONTROL ===
    if mpc_active and mpc_step < horizon:
        q_des = q_traj[:, mpc_step]
        dq_des = dq_traj[:, mpc_step]
        ddq_des = ddq_traj[:, mpc_step]

        torques = compute_torque_control(
            robot_id=env.robot_id,
            joint_indices=joint_indices,
            q=q,
            dq=dq,
            q_d=q_des,
            dq_d=dq_des,
            ddq_d=ddq_des
        )

        env.apply_joint_torques(torques)
        mpc_step += 1
    else:
        # No MPC trajectory or done: apply zero torque
        env.apply_joint_torques([0.0] * env.num_joints)
        mpc_active = False

    # === STEP SIMULATION ===
    env.step()
    time.sleep(dt)