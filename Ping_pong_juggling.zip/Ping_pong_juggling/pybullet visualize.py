import pybullet as p
import pybullet_data
import numpy as np
import time

# Initialize PyBullet with GUI
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())  # Used by loadURDF
p.setGravity(0, 0, -10)
planeId = p.loadURDF("plane.urdf")

# Load robot URDF (update the path as needed)
robot_id = p.loadURDF("universalUR5.urdf", useFixedBase=True)

# Get the number of joints in the robot
num_joints = p.getNumJoints(robot_id)

# Define the range for the sliders (min and max joint angles in radians)
joint_angle_ranges = {
    0: (-1.5, 1.5),  # Front-left hip joint (min, max)
    1: (-2.0, 0.0),  # Front-left knee joint (min, max)
    2: (-1.5, 1.5),  # Front-left ankle joint (min, max)
    3: (-1.5, 1.5),  # Back-left hip joint (min, max)
    4: (-2.0, 0.0),  # Back-left knee joint (min, max)
    5: (-1.5, 1.5),  # Back-left ankle joint (min, max)
    6: (-1.5, 1.5),  # Front-right hip joint (min, max)
    7: (-2.0, 0.0),  # Front-right knee joint (min, max)
    8: (-1.5, 1.5),  # Front-right ankle joint (min, max)
    9: (-1.5, 1.5),  # Back-right hip joint (min, max)
    10: (-2.0, 0.0), # Back-right knee joint (min, max)
    11: (-1.5, 1.5), # Back-right ankle joint (min, max)
}

# Initialize sliders for each joint
sliders = {}
for i in range(num_joints):
    min_angle, max_angle = joint_angle_ranges.get(i, (-100, 100))
    sliders[i] = p.addUserDebugParameter(f"Joint {i} Angle", min_angle, max_angle, 0.0)

# Function to update joint angles based on slider values
def update_joint_positions():
    joint_angles = []
    for i in range(num_joints):
        angle = p.readUserDebugParameter(sliders[i])
        joint_angles.append(angle)
        p.resetJointState(robot_id, i, angle)

    return joint_angles

# Visualize joints using debug lines
def visualize_joints():
    for i in range(num_joints):
        joint_info = p.getJointInfo(robot_id, i)
        joint_name = joint_info[1].decode('utf-8')

        # Get the world position and orientation of the joint
        joint_state = p.getLinkState(robot_id, i)
        joint_pos = joint_state[0]
        joint_orient = joint_state[1]

        # Visualize the joint position as a sphere
        p.addUserDebugLine(joint_pos, [joint_pos[0], joint_pos[1], joint_pos[2] + 0.1],
                           lineColorRGB=[1, 0, 0], lineWidth=3, lifeTime=0.1)

        # Add text label for the joint
        p.addUserDebugText(f"{joint_name}", joint_pos,
                           textColorRGB=[1, 1, 0], textSize=1.5, lifeTime=0.1)

# Optionally, reset the base position of the robot if needed
start_pos = [0, 0, 0.88]  # Example position
start_orientation = [0, 0, np.pi / 2, 1]  # Example orientation (quaternion)
p.resetBasePositionAndOrientation(robot_id, start_pos, start_orientation)

# Run the simulation and continuously update joint positions based on sliders
while True:
    joint_angles = update_joint_positions()
    print(f"Current Joint Angles: {joint_angles}")

    # Visualize joint positions and labels
    visualize_joints()

    # Step the simulation to update physics and visualization
    p.stepSimulation()

    # Sleep to slow down the loop and avoid too high CPU usage
    time.sleep(0.01)

# Disconnect when done (if you stop the loop manually)
p.disconnect()
